import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Home from './Home'; 
import NewHabit from './NewHabit'; 
import Signup from './Signup';
import Signin from './Signin';
import SignupInfo from './SignupInfo';
import Photo from './Photo';
import ImageRight from './ImageRight';
import ImageWrong from './ImageWrong';
import PoliPick from './PoliPick';
import PoliDem from './PoliDem';
import PoliRep from './PoliRep';



const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="Signup"
          component={Signup}
          options={{ title: 'Sign up' }}
        />
        <Stack.Screen
          name="Signin"
          component={Signin}
          options={{ title: 'Log in' }}
        />
        <Stack.Screen name="SignupInfo" component={SignupInfo}/>
        <Stack.Screen
          name="Home" 
          component={Home} 
          options={{ title: 'Home'}}
        />
        <Stack.Screen
          name="NewHabit"
          component={NewHabit} 
          options={{ title: 'New habit'}}
        />
        <Stack.Screen
          name="Photo"
          component={Photo} 
          options={{ title: 'Photo'}}
        />
        <Stack.Screen
          name="ImageRight"
          component={ImageRight} 
          options={{ title: 'Verify'}}
        />
        <Stack.Screen
          name="ImageWrong"
          component={ImageWrong} 
          options={{ title: 'Verify'}}
        />
        <Stack.Screen
          name="PoliPick"
          component={PoliPick} 
          options={{ title: 'A question'}}
        />
        <Stack.Screen
          name="PoliDem"
          component={PoliDem} 
          options={{ title: 'Republican'}}
        />
        <Stack.Screen
          name="PoliRep"
          component={PoliRep} 
          options={{ title: 'Democrat'}}
        />
        
      </Stack.Navigator>
    </NavigationContainer>
  );
}
