import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import styles from './styles'; // shared styling

const days = [
  { day: 'M', date: 2 },
  { day: 'T', date: 3 },
  { day: 'W', date: 4 },
  { day: 'T', date: 5 },
  { day: 'F', date: 6 },
  { day: 'S', date: 7 },
  { day: 'S', date: 8 },
];

const initialTasks = [
  { id: '1', text: 'Feed cat', due: 'today', color: 'red', completed: false },
  {
    id: '2',
    text: 'Make my bed',
    due: 'today',
    color: 'red',
    completed: false,
    photo: true,
  },
  {
    id: '3',
    text: 'Take out trash',
    due: 'tomorrow',
    color: 'orange',
    completed: false,
  },
  { id: '4', text: 'Shower', due: 'May 19', color: 'green', completed: true },
];

export default function Home({ navigation }) {
  const [tasks, setTasks] = useState(initialTasks);

  const toggleTask = (id) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const renderTask = (task) => (
  <Pressable
    key={task.id}
    style={styles.taskContainer}
    onPress={() => {
      if (task.photo) {
        navigation.navigate('Photo', { taskId: task.id });
      } else {
        toggleTask(task.id);
      }
    }}
  >
    <View
      style={[
        styles.checkbox,
        {
          borderColor: task.color,
          backgroundColor: task.completed ? task.color : 'transparent',
        },
      ]}
    >
      {task.completed && (
        <Ionicons name="checkmark" size={16} color="white" />
      )}
    </View>
    <Text style={styles.taskText}>{task.text}</Text>
  </Pressable>
);


  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Today is 4/26/2025</Text>
        <Text style={styles.subtitle}>Good morning, Olivia!</Text>
      </View>

      {/* Horizontal Calendar */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.calendar}>
        {days.map((item, index) => (
          <View key={index} style={styles.dayContainer}>
            <Text style={styles.dayText}>{item.day}</Text>
            <View style={styles.dateCircle}>
              <Text style={styles.dateText}>{item.date}</Text>
            </View>
          </View>
        ))}
      </ScrollView>

      {/* Task List */}
      <ScrollView style={styles.taskSection}>
        <Text style={styles.sectionTitle}>By today:</Text>
        {tasks.filter((t) => t.due === 'today').map(renderTask)}

        <Text style={styles.sectionTitle}>By tomorrow:</Text>
        {tasks.filter((t) => t.due === 'tomorrow').map(renderTask)}

        <Text style={styles.sectionTitle}>By May 19:</Text>
        {tasks.filter((t) => t.due === 'May 19').map(renderTask)}
      </ScrollView>

      {/* Floating + Button */}
      <Pressable
        style={styles.fab}
        onPress={() => navigation.navigate('NewHabit')}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Ionicons name="add" size={20} color="black" />
          <Text style={{ marginLeft: 4, fontSize: 16 }}>New habit</Text>
        </View>
      </Pressable>
    </View>
  );
}
